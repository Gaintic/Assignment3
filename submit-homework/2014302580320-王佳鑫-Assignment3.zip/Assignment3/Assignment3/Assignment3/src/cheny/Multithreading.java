package cheny;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.naming.MalformedLinkException;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
public class Multithreading  extends Thread{
	static String []urls=new String[15];
	static String []phone=new String[15];
	static String []email=new String[15];
	static String []name=new String[15];
	static String []backgrounds=new String[15];
	//JDBC ��������URL
	 static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";  
	 static final String DB_URL = "jdbc:mysql://localhost/EMP";
	  //  Database credentials
	static final String USER = "root";
	static final String PASS = "nan0103++";
	static boolean signal = false;
	 public static void main(String[] args) throws IOException, MalformedLinkException, InterruptedException{
		 long starTime=System.currentTimeMillis();
		 mm.getURLs();
		 r2.start();
		 r3.start();
		 mm.cin();
		 long endTime=System.currentTimeMillis();
		long Time=endTime-starTime;
	    System.out.println("���߳�����ʱ��Ϊ:"+Time);
	    long startTime=System.currentTimeMillis();
		Main m=new Main();
		m.getURLs();
		m.get2();
		m.cin();
		long endTim=System.currentTimeMillis();
		long Time1=endTim-startTime;
		  System.out.println("���߳�����ʱ��Ϊ:"+Time1);
	}
	 static Multithreading mm=new Multithreading();
		static Thread r1=new Thread(){
			public synchronized void run(){
				try {
					mm.getURLs();
					signal=true;
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			};
		static Thread r2=new Thread(){
			public  synchronized void run(){
				
				try {
					mm.get1();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
			};
		static Thread r3=new Thread(){
				public synchronized  void run(){
				try {
						mm.get2();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
				}
				
				};

		static Thread r4=new Thread(){
			   public synchronized void run(){
				  {
						mm.cin();
				   }
					}
					};	
		
		//�������URL��ַ
		void getURLs() throws IOException{
			
			String url="http://www.chem.whu.edu.cn/szdw.htm";
			Document doc=Jsoup.connect(url).get();
			Elements div=doc.getElementsByClass("list_teacher");
			Elements as=div.select("a");
			for(int a=28;a<43;a++){
				urls[a-28]=as.get(a).attr("abs:href");
				urls[a-28]=urls[a-28].replaceAll(" ","%20");
				System.out.println(urls[a-28]);
		}
		}
		
	   //��ȡ���Уգң�����
		void get1() throws IOException{
			String sum="";
			String back="";
			for(int i=0;i<7;i++){
			Document  docs=Jsoup.connect(urls[i]).get();
			Elements  divs=docs.select("div.details.col-md-10.col-sm-9.col-xs-7");
			Elements  dis=docs.getElementsByClass("szll_wz");
			Elements  pps=dis.select("p");
			Elements  ps=divs.select("p");
			Elements  h=divs.select("h3");
			sum=ps.text();
			for(Element p:pps){
				String aa=p.text();
				back+=aa;
			}
			
		    
			//�������Ѱ�ҵ绰������
			name[i]=h.text();
			backgrounds[i]=back;
			back="";
			Pattern pattern1=null;
			String re1="[0-9]+\\-+[0-9]{8}";
			String re2="[0-9]{11}";
			pattern1=Pattern.compile(re1);
			Pattern pattern3=Pattern.compile(re2);
			Matcher matcher1 = pattern1.matcher(sum);
			Matcher matcher3 = pattern3.matcher(sum);
			Pattern pattern2 = Pattern.compile("[a-z]+@[a-z]+\\.+[a-z]{3}+\\.+[a-z]{2}",Pattern.CASE_INSENSITIVE);
			Matcher matcher2 = pattern2.matcher(sum);
			while(matcher1.find()){
				phone[i]=matcher1.group();
				System.out.println("��ϵ�绰��"+phone[i]+i);
				};
			while(matcher3.find()){
				   phone[i]=matcher3.group();
					};
			while(matcher2.find()){
				email[i]=matcher2.group();
			System.out.println("������"+email[i]+i);
			}
			sum="";
			}
			}
		void get2() throws IOException{
			String sum="";
			String back="";
			for(int i=7;i<15;i++){
			Document  docs=Jsoup.connect(urls[i]).get();
			Elements  divs=docs.select("div.details.col-md-10.col-sm-9.col-xs-7");
			Elements  dis=docs.getElementsByClass("szll_wz");
			Elements  pps=dis.select("p");
			Elements  ps=divs.select("p");
			Elements  h=divs.select("h3");
			sum=ps.text();
			for(Element p:pps){
				String aa=p.text();
				back+=aa;
			}
			signal=true;
			//�������Ѱ�ҵ绰������
			name[i]=h.text();
			backgrounds[i]=back;
			back="";
			Pattern pattern1=null;
			String re1="[0-9]+\\-+[0-9]{8}";
			String re2="[0-9]{11}";
			pattern1=Pattern.compile(re1);
			Pattern pattern3=Pattern.compile(re2);
			Matcher matcher1 = pattern1.matcher(sum);
			Matcher matcher3 = pattern3.matcher(sum);
			Pattern pattern2 = Pattern.compile("[a-z]+@[a-z]+\\.+[a-z]{3}+\\.+[a-z]{2}",Pattern.CASE_INSENSITIVE);
			Matcher matcher2 = pattern2.matcher(sum);
			while(matcher1.find()){
				phone[i]=matcher1.group();
				System.out.println("��ϵ�绰��"+phone[i]+i);
				};
			while(matcher3.find()){
				   phone[i]=matcher3.group();
					};
			while(matcher2.find()){
				email[i]=matcher2.group();
			System.out.println("������"+email[i]+i);
			}
			sum="";
			}
			}
		
		//jdbc
		void cin(){
			 Connection conn = null;
			  Statement stmt = null;
			  try{
			      //STEP 2: Register JDBC driver
			      Class.forName("com.mysql.jdbc.Driver");

			      //STEP 3: Open a connection
			      System.out.println("Connecting to a selected database...");
			      conn = DriverManager.getConnection(DB_URL, USER, PASS);
			      System.out.println("Connected database successfully...");
			      
			      //STEP 4: Execute a query
			      System.out.println("Creating table in given database...");
			      stmt = conn.createStatement();
			      String sql="CREATE TABLE teachers ("+
			    		 " `name` varchar(45) COLLATE utf8_bin NOT NULL,"+
			    		  "`educationBackground` varchar(1000) COLLATE utf8_bin DEFAULT NULL,"+
			    		  "`email` varchar(45) COLLATE utf8_bin DEFAULT NULL,"+
			    		  "`phone` varchar(45) COLLATE utf8_bin DEFAULT NULL,"+
			    		  "PRIMARY KEY (`name`)"+
			    		") ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin";

			     stmt.executeUpdate(sql);
			      System.out.println("Created table in given database...");
			     for(int i=0;i<15;i++){
			         sql = "INSERT INTO teachers " +
				              "VALUES ('"+ name[i]+"','"+ backgrounds[i]+"','"+ email[i]+"','"+ phone[i]+"')";
				stmt.executeUpdate(sql);
			      }
			     
			 System.out.println("Inserted records into the table...");

			   }catch(SQLException se){
			      //Handle errors for JDBC
			      se.printStackTrace();
			   }catch(Exception e){
			      //Handle errors for Class.forName
			      e.printStackTrace();
			   }finally{
			      //finally block used to close resources
			      try{
			         if(stmt!=null)
			            conn.close();
			      }catch(SQLException se){
			      }// do nothing
			      try{
			         if(conn!=null)
			            conn.close();
			      }catch(SQLException se){
			         se.printStackTrace();
			      }//end finally try
			   }//end try
			   System.out.println("Goodbye!");
		}
		}


