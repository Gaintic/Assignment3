import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Conn {
	private static Connection getConn() throws SQLException {
		final String URL="jdbc:mysql://localhost:3306/teachers";
		final String USER="root";
		final String PASSWORD="01260926";
		Connection conn = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
    		conn=DriverManager.getConnection(URL,USER,PASSWORD);

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println("�Ҳ������������� ����������ʧ�ܣ�");  
			e.printStackTrace();
		}
		
	    return conn;
	}
	
	static int insert(Teacher teacher) throws SQLException {
	    Connection conn = getConn();
	    int i = 0;
	    String sql = "insert into teacherList (Name,Phone,Email,educationBackground) values(?,?,?,?)";
	    PreparedStatement pstmt;
	    try {
	        pstmt = (PreparedStatement) conn.prepareStatement(sql);
	        pstmt.setString(1, teacher.getName());
	        pstmt.setString(2, teacher.getEmail());
	        pstmt.setString(3, teacher.getPhone());
	        pstmt.setString(4, teacher.getBackground());
	        i = pstmt.executeUpdate();
	        pstmt.close();
	        conn.close();
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return i;	
	}
	
	
}
