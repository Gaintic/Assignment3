
public class Teacher {
    private String Name;
    private String Phone;
    private String Email;
    private String Background;

    Teacher(String Name, String Phone, String Email,String Background) {
        this.Name = Name;
        this.Phone = Phone;
        this.Email = Email;
        this.Background = Background;
    }

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public String getPhone() {
        return Phone;
    }

    public void setPhone(String Phone) {
        this.Phone = Phone;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String Email){
    	this.Email = Email;
    }
    
    public String getBackground(){
    	return Background;
    }
    
    public void setBackground(String Background){
    	this.Background = Background;
    }




}
