import java.io.File;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class Main2014302580320 {


	public static void main(String[] args) throws Exception{
		
		File Input = new File("teacherList.html");
		Document doc = Jsoup.parse(Input, "UTF-8");
		Elements url = doc.select("dd.j_name_table").select("a[href]");
	
		for(Element elem:url){
			String u = "http://cs.whu.edu.cn/plus/"+elem.attr("href");
			Document d = Jsoup.connect(u).get();
			//����
			Elements name = d.select("ul.about_info.fn_left").select("li:contains(����)");
			String n;
			if(name!=null){
			String N = name.text();
			String[] ph1 = N.split("��");
			n = ph1[1];
			}else n="null";
			//�绰
			Elements phone = d.select("ul.about_info.fn_left").select("li:contains(�绰)");
			String p;
			if(phone!=null){
			String P = phone.text();
			String[] ph2 = P.split("��");
			p = ph2[1];
			}else p="null";
			//����
			Elements mailbox = d.select("ul.about_info.fn_left").select("li:contains(E-mail)");
			String m;
			if(mailbox!=null){
			String M = mailbox.text();
			String[] ph3 = M.split("��");
			m = ph3[1];
			}else m="null";
		    //���
			Elements search = d.select("div.info_list_ct");
			String s;
			if(search!=null){
			String S = search.text();
			s = S.replace(Jsoup.parse("&nbsp;").text(), " ");
			}else s="null";
			
			Conn.insert(new Teacher(n,m,p,s));
		}
	}
}

