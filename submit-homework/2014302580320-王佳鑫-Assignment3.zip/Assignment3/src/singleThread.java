import java.io.File;
import java.io.IOException;



import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

//���߳���ȡ
public class singleThread {
	
	
	public static void getImformation() throws IOException, Exception{
		File Input = new File("teacherList.html");
		Document doc = Jsoup.parse(Input, "UTF-8");
		Elements url = doc.select("dd.j_name_table").select("a[href]");
	
		for(Element elem:url){
			String u = "http://cs.whu.edu.cn/plus/"+elem.attr("href");
			Document d = Jsoup.connect(u).get();
			//����
			Elements name = d.select("ul.about_info.fn_left").select("li:contains(����)");
			String N = name.text();
			String[] ph1 = N.split("��");
			String n = ph1[1];
			//�绰
			Elements phone = d.select("ul.about_info.fn_left").select("li:contains(�绰)");
			String P = phone.text();
			String[] ph2 = P.split("��");
			String p = ph2[1];
			//����
			Elements mailbox = d.select("ul.about_info.fn_left").select("li:contains(E-mail)");
			String M = mailbox.text();
			String[] ph3 = M.split("��");
			String m = ph3[1];
		    //���
			Elements search = d.select("div.info_list_ct");
			String S0 = search.text();
			String S = S0.replace(Jsoup.parse("&nbsp;").text(), " ");
			String[] ph4 = S.split("��");
			String s = ph4[1];
			
			Conn.insert(new Teacher(n,m,p,s));
		}
	}


}
