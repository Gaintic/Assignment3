
public class multiThread extends Thread{

}
